// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"

#include "NontaoImportExportStructs.h"

//...
#include <assimp/include/assimp/Exporter.hpp>
#include <assimp/include/assimp/scene.h>

#include "NontaoExporter.generated.h"

/**
 * 
 */
UCLASS(BlueprintType)
class NONTAOIMPORTEXPORT_API UNontaoExporter : public UObject
{
	GENERATED_BODY()

public:

	UNontaoExporter(const FObjectInitializer& ObjectInitializer);
	~UNontaoExporter();

	UFUNCTION(BlueprintCallable, Category = "Nontao|Export")
	bool ExportWithDialog(const FNontaoScene& Scene);

	UFUNCTION(BlueprintCallable, Category = "Nontao|Export")
	bool Export(const FNontaoScene& Scene, const FString& FormatId, const FString& File);

	void Clear();

protected:
	bool Parse(const FNontaoScene& Scene);
	bool ParseScene(const FNontaoScene& Scene);
	int ParseMetas(const TArray<FNontaoMeta>& Metas);
	int ParseTextures(const TArray<FNontaoTexture>& Textures);
	int ParseMaterials(const TArray<FNontaoMaterial>& Material);
	int ParseMeshes(const TArray<FNontaoMesh>& Meshes);
	int ParseLights(const TArray<FNontaoLight>& Lights);
	int ParseCameras(const TArray<FNontaoCamera>& Cameras);
	int ParseAnimations(const TArray<FNontaoAnimation>& Animations);
	int ParseNodes(const TArray<FNontaoNode>& Node);

protected:
	//aiScene mScene;
	std::unique_ptr<aiScene> mScene;
};
