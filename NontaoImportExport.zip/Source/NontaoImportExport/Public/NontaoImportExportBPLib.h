// Copyright 2016-2020 Nontao. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"

#include "NontaoImportExportStructs.h"

#include "NontaoImportExportBPLib.generated.h"

/**
 * 
 */
UCLASS()
class NONTAOIMPORTEXPORT_API UNontaoImportExportBPLib : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()
	
public:
	UFUNCTION(BlueprintCallable, Category = "Nontao|Import")
	static bool OpenFileDialog(const FString& Title, const FString& FileTypes, TArray<FString>& OutFilenames);


	UFUNCTION(BlueprintCallable, Category = "Nontao|Import")
	static bool SaveFileDialog(const FString& Title, const FString& FileTypes, TArray<FString>& OutFilenames);

	static void* GetWindowHandle();

};
