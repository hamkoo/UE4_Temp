// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"


#include "NontaoImportExportStructs.generated.h"


UENUM(BlueprintType)
enum class ENontaoTextureType : uint8
{
	TextureType_NONE = 0,
	TextureType_DIFFUSE = 1,
	TextureType_SPECULAR = 2,
	TextureType_AMBIENT = 3,
	TextureType_EMISSIVE = 4,
	TextureType_HEIGHT = 5,
	TextureType_NORMALS = 6,
	TextureType_SHININESS = 7,
	TextureType_OPACITY = 8,
	TextureType_DISPLACEMENT = 9,
	TextureType_LIGHTMAP = 10,
	TextureType_REFLECTION = 11,
	TextureType_BASE_COLOR = 12,
	TextureType_NORMAL_CAMERA = 13,
	TextureType_EMISSION_COLOR = 14,
	TextureType_METALNESS = 15,
	TextureType_DIFFUSE_ROUGHNESS = 16,
	TextureType_AMBIENT_OCCLUSION = 17,
	TextureType_UNKNOWN = 18,
};


UENUM(BlueprintType)
enum class ENontaoLightSourceType : uint8
{
	LightSource_UNDEFINED = 0x0,
	LightSource_DIRECTIONAL = 0x1,
	LightSource_POINT = 0x2,
	LightSource_SPOT = 0x3,
	LightSource_AMBIENT = 0x4,
	LightSource_AREA = 0x5,
};


UENUM(BlueprintType)
enum class ENontaoDataType : uint8
{
	Nontao_BOOL = 0,
	Nontao_INT32 = 1,
	Nontao_UINT64 = 2,
	Nontao_FLOAT = 3,
	Nontao_DOUBLE = 4,
	Nontao_STRING = 5,
	Nontao_VECTOR = 6,
	Nontao_VECTOR2D = 7,
	//...
} ;


// -------------------------------------------------------------------------------
/**
  * Container for holding metadata.
  *
  * Metadata is a key-value store using string keys and values.
  */
  // -------------------------------------------------------------------------------
USTRUCT(BlueprintType)
struct NONTAOIMPORTEXPORT_API FNontaoMeta {
	GENERATED_BODY()
		
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FString Name;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		ENontaoDataType Type;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<int> Data;
};

USTRUCT(BlueprintType)
struct NONTAOIMPORTEXPORT_API FNontaoVectorArray {
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	TArray<FVector> Array;
};

USTRUCT(BlueprintType)
struct NONTAOIMPORTEXPORT_API FNontaoVector2DArray {
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	TArray<FVector2D> Array;
};

USTRUCT(BlueprintType)
struct NONTAOIMPORTEXPORT_API FNontaoLinearColorArray {
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	TArray<FLinearColor> Array;
};

USTRUCT(BlueprintType)
struct NONTAOIMPORTEXPORT_API FNontaoTexture {
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FString FileName;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FString FormatHint;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		int Width;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		int Height;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<uint8> Data;
};

UENUM(BlueprintType)
enum class ENontaoPropertyType : uint8
{
	PTI_Unknown = 0x0,
	PTI_Float = 0x1,
	PTI_Double = 0x2,
	PTI_String = 0x3,
	PTI_Integer = 0x4,
	PTI_Buffer = 0x5,
};

USTRUCT(BlueprintType)
struct NONTAOIMPORTEXPORT_API FNontaoMaterialProperty {
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FString Name;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<int> Data;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		int Index;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		int Semantic;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		ENontaoPropertyType Type;
};

USTRUCT(BlueprintType)
struct NONTAOIMPORTEXPORT_API FNontaoMaterial {
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FString Name;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<FNontaoMaterialProperty> Properties;
	/** Storage allocated */
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		int NumAllocated;
};

USTRUCT(BlueprintType)
struct NONTAOIMPORTEXPORT_API FNontaoWeight {
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		int VertexId;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		float Weight;
};

USTRUCT(BlueprintType)
struct NONTAOIMPORTEXPORT_API FNontaoBone {
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FString Name;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<FNontaoWeight> Weights;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FMatrix OffsetMatrix;
};

USTRUCT(BlueprintType)
struct NONTAOIMPORTEXPORT_API FNontaoAnimMesh {
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FString Name;

	
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<FVector> Vertices;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<FVector> Normals;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<FVector> Tangents;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<FVector> Bitangents;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<FNontaoLinearColorArray>  Colors;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	TArray<FNontaoVector2DArray>  UVs;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		float Weight;
};

USTRUCT(BlueprintType)
struct NONTAOIMPORTEXPORT_API FNontaoVectorKey {
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		float Time;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FVector Value;
};

USTRUCT(BlueprintType)
struct NONTAOIMPORTEXPORT_API FNontaoQuatKey {
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		float Time;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FQuat Value;
};

USTRUCT(BlueprintType)
struct NONTAOIMPORTEXPORT_API FNontaoMeshKey {
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		float Time;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		int Value;
};

USTRUCT(BlueprintType)
struct NONTAOIMPORTEXPORT_API FNontaoMeshMorphKey {
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		float Time;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<int> Values;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<float> Weights;
};


USTRUCT(BlueprintType)
struct NONTAOIMPORTEXPORT_API FNontaoNodeAnim {
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FString Name;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<FNontaoVectorKey> PositionKeys;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<FNontaoQuatKey> RotationKeys;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<FNontaoVectorKey> ScalingKeys;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		int PreState;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		int PostState;
};

USTRUCT(BlueprintType)
struct NONTAOIMPORTEXPORT_API FNontaoMeshAnim {
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FString Name;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<FNontaoMeshKey> Keys;
};


USTRUCT(BlueprintType)
struct NONTAOIMPORTEXPORT_API FNontaoMeshMorphAnim {
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FString Name;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<FNontaoMeshMorphKey> Keys;
};



USTRUCT(BlueprintType)
struct NONTAOIMPORTEXPORT_API FNontaoAnimation {
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FString Name;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		float Druation;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		float TicksPerSecond;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<FNontaoNodeAnim> Channels;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<FNontaoMeshAnim> MeshChannels;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<FNontaoMeshMorphAnim> MorphMeshChannels;
};

USTRUCT(BlueprintType)
struct NONTAOIMPORTEXPORT_API FNontaoMesh {
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FString Name;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<FVector> Vertices;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<int32> Triangles;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<FVector> Normals;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<FNontaoVector2DArray> UVs;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<int> NumUVComponents;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<FNontaoLinearColorArray> VertexColors;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<FVector> Tangents;
	//UPROPERTY(BlueprintReadWrite, EditAnywhere)
	//	FTransform RelativeTransform;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		int32 MaterialIndex;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		int PrimitiveType;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<FNontaoBone> Bones;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<FNontaoAnimMesh> AnimMeshes;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		int Method;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FBox Box;
};

USTRUCT(BlueprintType)
struct NONTAOIMPORTEXPORT_API FNontaoLight {
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FString Name;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		ENontaoLightSourceType Type;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FVector Position;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FVector Direction;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FVector Up;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		float AttenuationConstant;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		float AttenuationLinear;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		float AttenuationQuadratic;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FLinearColor ColorDiffuse;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FLinearColor ColorSpecular;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FLinearColor ColorAmbient;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		float AngleInnerCone;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		float AngleOuterCone;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FVector2D Size;
};

USTRUCT(BlueprintType)
struct NONTAOIMPORTEXPORT_API FNontaoCamera {
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	FString Name;
	//...
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FVector Position;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FVector LookAt;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FVector Up;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		float HorizontalFOV;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		float ClipPlaneNear;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		float ClipPlaneFar;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		float Aspect;
};


USTRUCT(BlueprintType)
struct NONTAOIMPORTEXPORT_API FNontaoNode {
	GENERATED_BODY()

public:
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FString Name;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FTransform Transform;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<int> Meshes;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<FNontaoMeta> Metas;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<int> Children;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		int Parent;
	
	FNontaoNode() {
		Parent = -1;
	};
};

USTRUCT(BlueprintType)
struct NONTAOIMPORTEXPORT_API FNontaoScene
{
	GENERATED_BODY()

	FNontaoScene() {
		//Root = NewObject<UNontaoNode>();
	}

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		FMatrix Matrix4Axis;

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<FNontaoMeta> Metas;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<FNontaoTexture> Textures;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<FNontaoMaterial> Materials;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<FNontaoMesh> Meshes;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<FNontaoLight> Lights;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<FNontaoCamera> Cameras;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<FNontaoAnimation> Animations;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		TArray<FNontaoNode> Nodes;

public:
	void Reset() {
		Animations.Empty();
		Cameras.Empty();
		Lights.Empty();
		Materials.Empty();
		Meshes.Empty();
		Metas.Empty();
		Textures.Empty();
		Nodes.Empty();
	}
};

