// Copyright 2016-2020 Nontao. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

#include "UObject/NoExportTypes.h"
#include "UObject/UObjectGlobals.h"

#include "NontaoImportExportStructs.h"

//...
#include <assimp/include/assimp/Importer.hpp>
#include <assimp/include/assimp/scene.h>
#include <assimp/include/assimp/mesh.h>
#include <assimp/include/assimp/postprocess.h>



#include "NontaoImporter.generated.h"


USTRUCT(BlueprintType)
struct NONTAOIMPORTEXPORT_API FNontaoImportOptions {
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		bool ImportTextures;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		bool ImportMaterials;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		bool ImportMeshes; 
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		bool ImportSkeletons;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		bool ImportAnimations;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		bool ImportLights;
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		bool ImportCameras;

};

/**
 * 
 */
UCLASS(BlueprintType)
class NONTAOIMPORTEXPORT_API UNontaoImporter : public UObject
{
	GENERATED_BODY()
	
public:

	UNontaoImporter(const FObjectInitializer& ObjectInitializer);
	~UNontaoImporter();

	// 1)
	UFUNCTION(BlueprintCallable, Category = "Nontao|Import")
	bool LoadFile(const FString& File, const FNontaoImportOptions& ImportOptions);

	UFUNCTION(BlueprintCallable, Category = "Nontao|Import")
	bool LoadBuffer(const TArray<uint8>& Buffer, const FNontaoImportOptions& ImportOptions);

	UFUNCTION(BlueprintCallable, Category = "Nontao|Import")
	bool LoadFromMemory(const FNontaoImportOptions& ImportOptions);

	UFUNCTION(BlueprintCallable, Category = "Nontao|Import")
	const FString GetDetails();

	UFUNCTION(BlueprintCallable, Category = "Nontao|Import")
		const FString GetTextureJson(const FNontaoTexture& Value);
	UFUNCTION(BlueprintCallable, Category = "Nontao|Import")
		const FString GetMaterialJson(const FNontaoMaterial& Value);
	UFUNCTION(BlueprintCallable, Category = "Nontao|Import")
		const FString GetMeshJson(const FNontaoMesh& Value);
	UFUNCTION(BlueprintCallable, Category = "Nontao|Import")
		const FString GetLightJson(const FNontaoLight& Value);
	UFUNCTION(BlueprintCallable, Category = "Nontao|Import")
		const FString GetCameraJson(const FNontaoCamera& Value);
	UFUNCTION(BlueprintCallable, Category = "Nontao|Import")
		const FString GetAnimationJson(const FNontaoAnimation& Value);
	UFUNCTION(BlueprintCallable, Category = "Nontao|Import")
		const FString GetMetaJson(const FNontaoMeta& Value);
	UFUNCTION(BlueprintCallable, Category = "Nontao|Import")
		const FString GetNodeJson(const FNontaoNode& Value);

protected:

	void Clear();

	bool Parse(const aiScene* Scene);
	bool ParseScene(const aiScene* Scene);
	int ParseMetas(const aiScene* Scene);
	int ParseTextures(const aiScene* Scene);
	int ParseMaterials(const aiScene* Scene);
	int ParseMeshes(const aiScene* Scene);
	int ParseLights(const aiScene* Scene);
	int ParseCameras(const aiScene* Scene);
	int ParseAnimations(const aiScene* Scene);
	int ParseNodes(const aiScene* Scene);
public:
	UPROPERTY(BlueprintReadOnly, Category = "Nontao|Import", EditAnywhere)
	FNontaoScene NontaoScene;
	UPROPERTY(BlueprintReadOnly, Category = "Nontao|Import", EditAnywhere)
	FString FileName;
protected:

};
