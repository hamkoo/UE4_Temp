// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"

//...
#include <assimp/include/assimp/Importer.hpp>
#include <assimp/include/assimp/scene.h>
#include <assimp/include/assimp/mesh.h>
#include <assimp/include/assimp/postprocess.h>

/**
 * 
 */
class NONTAOIMPORTEXPORT_API NontaoImportExportUtils
{
public:
	NontaoImportExportUtils();
	~NontaoImportExportUtils();

	static FString GetTextureTypeString(const aiTextureType type);
	static FString GetLightTypeString(const aiLightSourceType type);

	static const FString GetString(const aiString* value);
	static const FString GetString(const aiString& value);
	//static void GetString(const aiString* value, FString& OutValue);

	static FMatrix GetMatrix(const aiMatrix4x4* matrix4x4);
	static FMatrix GetMatrix(const aiMatrix4x4& matrix4x4);
	static void GetMatrix(const aiMatrix4x4& matrix4x4, FMatrix& OutMatrix);
	static void GetMatrix(const FMatrix& OutMatrix, aiMatrix4x4& matrix4x4);

	static FVector GetVector(const aiVector3D* vec);
	static FVector GetVector(const aiVector3D& vec);
	static void GetVector(const aiVector3D& vec, FVector& OutValue);

	static FVector2D GetVector2D(const aiVector3D* vec);
	static FVector2D GetVector2D(const aiVector3D& vec);
	static void GetVector2D(const aiVector3D& vec, FVector2D& OutValue);

	static FLinearColor GetLinearColor(const aiColor4D* color);
	static FLinearColor GetLinearColor(const aiColor4D& color);
	
	static FLinearColor GetLinearColor(const aiColor3D* color);
	static FLinearColor GetLinearColor(const aiColor3D& color);
	static void GetLinearColor(const aiColor3D& color, FLinearColor& OutValue);
	static void GetLinearColor(const aiColor4D& color, FLinearColor& OutValue);
	//static void GetLinearColor(const aiColor4D& color, FLinearColor& OutValue);
	static void GetColor(const FLinearColor& color, aiColor3D& OutValue);
	static void GetColor(const FLinearColor& color, aiColor4D& OutValue);

	static FColor GetColor(const aiColor4D* color);
	static FColor GetColor(const aiColor4D& color);
	static void GetColor(const aiColor4D& color, FColor& OutValue);

	static void GetQuaternion(const aiQuaternion& quat, FQuat& OutValue);
	static void GetQuaternion(const FQuat& quat, aiQuaternion& OutValue);

	static void GetVector(const FVector& vec, aiVector3D& OutValue);
	static void GetVector(const FVector2D& vec, aiVector3D& OutValue);

	//static void GetColor(const FLinearColor& color, aiColor4D& OutValue);



	static void GetArray(TArray<int>* Dst, const void* Src, const unsigned int Size);
	static void GetArray(TArray<int>& Dst, const void* Src, const unsigned int Size);
	
	template<typename D>
	static void GetArray(TArray<D>& Dst, const void* Src, const unsigned int Size) {
		
		int count = Size / sizeof(D) + (Size % sizeof(D) != 0);
		Dst.AddUninitialized(count);
		FMemory::Memcpy(Dst.GetData(), Src, Size);
	};

	template<typename D, typename S>
	static void GetArray(TArray<D>& Dst, const void* Src) {

		int count = sizeof(S) / sizeof(D) + (sizeof(S) % sizeof(D) !=0);
		int size = sizeof(S);
		Dst.AddUninitialized(count);
		FMemory::Memcpy(Dst.GetData(), Src, size);
	};


	static const aiString GetString(const FString& Value);

	template<typename S>
	static const aiString GetString(const TArray<S>& Value);
	
	template<typename S>
	static const int GetData(void* Dst, const TArray<S>& Value);

	template<typename D, typename S>
	static const int GetData(void* Dst, const TArray<S>& Value);


	static const int GetMetadata(const TArray<FNontaoMeta>& Metas, aiMetadata*& Out );
};
