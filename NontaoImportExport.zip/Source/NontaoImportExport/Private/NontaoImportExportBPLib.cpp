// Copyright 2016-2020 Nontao. All Rights Reserved.


#include "NontaoImportExportBPLib.h"

#include "DesktopPlatform/Public/IDesktopPlatform.h"
#include "DesktopPlatform/Public/DesktopPlatformModule.h"
//#include "MainFrame/Public/Interfaces/IMainFrameModule.h"

#include "HAL/PlatformFile.h"
#include "HAL/PlatformFilemanager.h"
#include "Widgets/SWindow.h"
//#include "Engine/Engine.h"
//#include "Modules/ModuleManager.h"
//#include "Modules/ModuleInterface.h"



void* UNontaoImportExportBPLib::GetWindowHandle()
{
	//if (GIsEditor)
	//{
	//	IMainFrameModule& MainFrameModule = IMainFrameModule::Get();
	//	TSharedPtr<SWindow> MainWindow = MainFrameModule.GetParentWindow();

	//	if (MainWindow.IsValid() && MainWindow->GetNativeWindow().IsValid())
	//	{
	//		return MainWindow->GetNativeWindow()->GetOSWindowHandle();
	//	}
	//}
	//else
	//{
	//	if (GEngine && GEngine->GameViewport)
	//	{
	//		return GEngine->GameViewport->GetWindow()->GetNativeWindow()->GetOSWindowHandle();
	//	}
	//}

	return nullptr;
}

bool UNontaoImportExportBPLib::OpenFileDialog(const FString& Title, const FString& FileTypes, TArray<FString>& OutFilenames)
{
	IDesktopPlatform* DesktopPlatform = FDesktopPlatformModule::Get();
	void* ParentWindowWindowHandle = GetWindowHandle();

	//IMainFrameModule& MainFrameModule = FModuleManager::LoadModuleChecked<IMainFrameModule>(TEXT("MainFrame"));
	//const TSharedPtr<SWindow>& MainFrameParentWindow = MainFrameModule.GetParentWindow();
	//if (MainFrameParentWindow.IsValid() && MainFrameParentWindow->GetNativeWindow().IsValid())
	//{
	//	ParentWindowWindowHandle = MainFrameParentWindow->GetNativeWindow()->GetOSWindowHandle();
	//}

	auto rst = DesktopPlatform->OpenFileDialog(
		ParentWindowWindowHandle,
		Title,
		TEXT(""),
		TEXT(""),
		FileTypes, //TEXT("All Files (*.*)|*.*"),
		EFileDialogFlags::None,
		OutFilenames
	);

	return rst;
}


bool UNontaoImportExportBPLib::SaveFileDialog(const FString& Title, const FString& FileTypes, TArray<FString>& OutFilenames)
{
	IDesktopPlatform* DesktopPlatform = FDesktopPlatformModule::Get();
	void* ParentWindowWindowHandle = GetWindowHandle;

	//IMainFrameModule& MainFrameModule = FModuleManager::LoadModuleChecked<IMainFrameModule>(TEXT("MainFrame"));
	//const TSharedPtr<SWindow>& MainFrameParentWindow = MainFrameModule.GetParentWindow();
	//if (MainFrameParentWindow.IsValid() && MainFrameParentWindow->GetNativeWindow().IsValid())
	//{
	//	ParentWindowWindowHandle = MainFrameParentWindow->GetNativeWindow()->GetOSWindowHandle();
	//}

	auto rst = DesktopPlatform->SaveFileDialog(
		ParentWindowWindowHandle,
		Title,
		TEXT(""),
		TEXT(""),
		FileTypes, //TEXT("All Files (*.*)|*.*"),
		EFileDialogFlags::None,
		OutFilenames
	);

	return rst;
}