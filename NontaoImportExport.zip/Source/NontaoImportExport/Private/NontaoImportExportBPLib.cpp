// Fill out your copyright notice in the Description page of Project Settings.


#include "NontaoImportExportBPLib.h"

#include "DesktopPlatform/Public/IDesktopPlatform.h"
#include "DesktopPlatform/Public/DesktopPlatformModule.h"
#include "MainFrame/Public/Interfaces/IMainFrameModule.h"

#include "PlatformFile.h"
#include "PlatformFilemanager.h"
#include "Widgets/SWindow.h"
#include "Engine/Engine.h"
#include "Modules/ModuleManager.h"
#include "Modules/ModuleInterface.h"


bool UNontaoImportExportBPLib::OpenFileDialog(const FString& Title, const FString& FileTypes, TArray<FString>& OutFilenames)
{
	IDesktopPlatform* DesktopPlatform = FDesktopPlatformModule::Get();
	void* ParentWindowWindowHandle = nullptr;

	IMainFrameModule& MainFrameModule = FModuleManager::LoadModuleChecked<IMainFrameModule>(TEXT("MainFrame"));
	const TSharedPtr<SWindow>& MainFrameParentWindow = MainFrameModule.GetParentWindow();
	if (MainFrameParentWindow.IsValid() && MainFrameParentWindow->GetNativeWindow().IsValid())
	{
		ParentWindowWindowHandle = MainFrameParentWindow->GetNativeWindow()->GetOSWindowHandle();
	}

	auto rst = DesktopPlatform->OpenFileDialog(
		ParentWindowWindowHandle,
		Title,
		TEXT(""),
		TEXT(""),
		FileTypes, //TEXT("All Files (*.*)|*.*"),
		EFileDialogFlags::None,
		OutFilenames
	);

	return rst;
}


bool UNontaoImportExportBPLib::SaveFileDialog(const FString& Title, const FString& FileTypes, TArray<FString>& OutFilenames)
{
	IDesktopPlatform* DesktopPlatform = FDesktopPlatformModule::Get();
	void* ParentWindowWindowHandle = nullptr;

	IMainFrameModule& MainFrameModule = FModuleManager::LoadModuleChecked<IMainFrameModule>(TEXT("MainFrame"));
	const TSharedPtr<SWindow>& MainFrameParentWindow = MainFrameModule.GetParentWindow();
	if (MainFrameParentWindow.IsValid() && MainFrameParentWindow->GetNativeWindow().IsValid())
	{
		ParentWindowWindowHandle = MainFrameParentWindow->GetNativeWindow()->GetOSWindowHandle();
	}

	auto rst = DesktopPlatform->SaveFileDialog(
		ParentWindowWindowHandle,
		Title,
		TEXT(""),
		TEXT(""),
		FileTypes, //TEXT("All Files (*.*)|*.*"),
		EFileDialogFlags::None,
		OutFilenames
	);

	return rst;
}