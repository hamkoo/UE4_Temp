// Copyright 2016-2020 Nontao. All Rights Reserved.


#include "NontaoExporter.h"


#include "NontaoImporter.h"

#include "NontaoImportExportUtils.h"


#include <assimp/include/assimp/metadata.h>
//#include <assimp/include/assimp/Importer.hpp>

#include <functional>


UNontaoExporter::UNontaoExporter(const FObjectInitializer& ObjectInitializer)
	: UObject(ObjectInitializer)
{
	mScene.reset(new aiScene());
}

UNontaoExporter::~UNontaoExporter() {
	mScene.release();
}

void UNontaoExporter::Clear() {

}

bool UNontaoExporter::Parse(const FNontaoScene& Scene) {

	Clear();

	ParseScene(Scene);
	ParseMetas(Scene.Metas);
	ParseTextures(Scene.Textures);
	ParseMaterials(Scene.Materials);
	ParseMeshes(Scene.Meshes);
	ParseLights(Scene.Lights);
	ParseCameras(Scene.Cameras);
	ParseNodes(Scene.Nodes);
	ParseAnimations(Scene.Animations);

	return true;

}

bool UNontaoExporter::ParseScene(const FNontaoScene& Scene) {

	//aiScene& mScene = scene;
	//mScene.mFlags = 0;
	//mScene.mRootNode = NULL;
	//mScene.mNumMeshes = 0;
	//mScene.mMeshes = NULL;
	//mScene.mNumMaterials = 0;
	//mScene.mMaterials = NULL;
	//mScene.mNumAnimations = 0;
	//mScene.mAnimations = NULL;
	//mScene.mNumTextures = 0;
	//mScene.mTextures = NULL;
	//mScene.mNumLights = 0;
	//mScene.mLights = NULL;
	//mScene.mNumCameras = 0;
	//mScene.mCameras = NULL;
	//mScene.mPrivate = NULL;
	//mScene.mMetaData = NULL;

	return true;
}


int UNontaoExporter::ParseMetas(const TArray<FNontaoMeta>& Metas) {

	aiMetadata*& metadata = mScene->mMetaData;
	NontaoImportExportUtils::GetMetadata(Metas, metadata);
	return true;
}

int UNontaoExporter::ParseTextures(const TArray<FNontaoTexture>& Textures) {

	auto num = Textures.Num();

	mScene->mNumTextures = num;
	mScene->mTextures = new aiTexture*[num];
	auto texArray = new aiTexture[num]();
	for (size_t t = 0; t < num; t++)
	{
		auto aiTex = mScene->mTextures[t] = &texArray[t];
		auto& texture = Textures[t];
		memcpy(aiTex->achFormatHint, TCHAR_TO_UTF8(*texture.FormatHint), texture.FormatHint.Len() * sizeof(char));
		aiTex->mFilename = NontaoImportExportUtils::GetString(texture.FileName);
		aiTex->mHeight = texture.Height;
		aiTex->mWidth = texture.Width;
		auto size = aiTex->mWidth;
		if (aiTex->mHeight) {
			size *= aiTex->mHeight;
		}
		aiTex->pcData = (aiTexel*)malloc(size);
		FMemory::Memcpy(aiTex->pcData, texture.Data.GetData(), size);
	}

	return true;
}

int UNontaoExporter::ParseMaterials(const TArray<FNontaoMaterial>& Materials) {

	auto num = Materials.Num();

	mScene->mNumMaterials = num;
	mScene->mMaterials = new aiMaterial*[num];
	auto matArray = new aiMaterial[num]();
	for (size_t m = 0; m < num; m++)
	{
		auto& material = Materials[m];
		auto aiMat = mScene->mMaterials[m] = &matArray[m];

		if (1) {

			for (size_t p = 0; p < material.Properties.Num(); p++)
			{
				auto& prop = material.Properties[p];
				const auto index = prop.Index;
				const auto key = NontaoImportExportUtils::GetString(prop.Name).C_Str();
				const auto semantic = prop.Semantic;
				const auto type = (aiPropertyTypeInfo)prop.Type;

				switch (type)
				{
				case aiPropertyTypeInfo::aiPTI_Buffer:
				{
					aiMat->AddBinaryProperty(prop.Data.GetData(), prop.Data.GetAllocatedSize(), key, semantic, index, type);
					break;
				}
				case aiPropertyTypeInfo::aiPTI_Double:
				{
					const double value = *prop.Data.GetData();
					aiMat->AddProperty(&value, 1, key, semantic, index);
					break;
				}
				case aiPropertyTypeInfo::aiPTI_Float:
				{
					const float value = *prop.Data.GetData();
					aiMat->AddProperty(&value, 1, key, semantic, index);
					break;
				}
				case aiPropertyTypeInfo::aiPTI_Integer:
				{
					const int value = *prop.Data.GetData();
					aiMat->AddProperty(&value, 1, key, semantic, index);
					break;
				}
				case aiPropertyTypeInfo::aiPTI_String:
				{
					aiString value(TCHAR_TO_UTF8(prop.Data.GetData()));
					aiMat->AddProperty(&value, key, semantic, index);
					break;
				}
				default:
					break;
				}
			}
		}
	}

	return true;
}

int UNontaoExporter::ParseMeshes(const TArray<FNontaoMesh>& Meshes) {

	auto num = Meshes.Num();

	mScene->mNumMeshes = Meshes.Num();
	mScene->mMeshes = new aiMesh*[Meshes.Num()];
	auto aiMesArray = new aiMesh[Meshes.Num()]();
	for (size_t m = 0; m < Meshes.Num(); m++)
	{
		auto& mesh = Meshes[m];
		auto aiMes = mScene->mMeshes[m] = &aiMesArray[m];

		aiMes->mMaterialIndex = mesh.MaterialIndex;
		aiMes->mMethod = mesh.Method;
		aiMes->mName = aiString(std::string(TCHAR_TO_UTF8(* mesh.Name)));
		aiMes->mPrimitiveTypes = mesh.PrimitiveType;
		NontaoImportExportUtils::GetVector(mesh.Box.Max, aiMes->mAABB.mMax);
		NontaoImportExportUtils::GetVector(mesh.Box.Min, aiMes->mAABB.mMin);
		
		aiMes->mNumVertices = mesh.Vertices.Num();
		aiMes->mVertices = new aiVector3D[mesh.Vertices.Num()];
		aiMes->mNormals = new aiVector3D[mesh.Vertices.Num()];
		if (aiMes->HasTangentsAndBitangents()) {
			aiMes->mTangents = new aiVector3D[mesh.Vertices.Num()];
			//aiMes->mBitangents = new aiVector3D[mesh.Vertices.Num()];		
		}

		for (size_t c = 0; c < mesh.VertexColors.Num() && c < AI_MAX_NUMBER_OF_COLOR_SETS; c++)
		{
			if (mesh.VertexColors[c].Array.Num() > 0) {
				aiMes->mColors[c] = new aiColor4D[mesh.Vertices.Num()];			
			}
		}

		for (size_t uv = 0; uv < mesh.UVs.Num() && uv < AI_MAX_NUMBER_OF_TEXTURECOORDS; uv++)
		{
			if (mesh.UVs[uv].Array.Num() > 0) {
				aiMes->mTextureCoords[uv] = new aiVector3D[mesh.Vertices.Num()];			
			}

			aiMes->mNumUVComponents[uv] = mesh.NumUVComponents[uv];
		}

		for (size_t v = 0; v < mesh.Vertices.Num(); v++)
		{
			NontaoImportExportUtils::GetVector(mesh.Vertices[v], aiMes->mVertices[v]);
			NontaoImportExportUtils::GetVector(mesh.Normals[v], aiMes->mNormals[v]);
			if (aiMes->HasTangentsAndBitangents()) {
				NontaoImportExportUtils::GetVector(mesh.Tangents[v], aiMes->mTangents[v]);
				//NontaoImportExportUtils::GetVector(mesh.[v], aiMes->mBitangents[v]);			
			}


			for (size_t c = 0; c < mesh.VertexColors.Num() && c < AI_MAX_NUMBER_OF_COLOR_SETS; c++)
			{
				if (mesh.VertexColors[c].Array.Num() > 0) {
					NontaoImportExportUtils::GetColor(mesh.VertexColors[c].Array[v], aiMes->mColors[c][v]);
				}
			}

			for (size_t uv = 0; uv < mesh.UVs.Num() && uv < AI_MAX_NUMBER_OF_TEXTURECOORDS; uv++)
			{
				if (mesh.UVs[uv].Array.Num() > 0) {
					NontaoImportExportUtils::GetVector(mesh.UVs[uv].Array[v], aiMes->mTextureCoords[uv][v]);
				}
			}			
		}

		aiMes->mNumFaces = mesh.Triangles.Num() / 3;
		aiMes->mFaces = new aiFace[aiMes->mNumFaces];
		for (size_t f = 0; f < aiMes->mNumFaces; f++)
		{
			auto& aiFac = aiMes->mFaces[f];
			aiFac.mNumIndices = 3;
			aiFac.mIndices = new unsigned int[aiFac.mNumIndices];
			aiFac.mIndices[0] = mesh.Triangles[f * 3 + 0];
			aiFac.mIndices[1] = mesh.Triangles[f * 3 + 1];
			aiFac.mIndices[2] = mesh.Triangles[f * 3 + 2];
		}

		aiMes->mNumBones = mesh.Bones.Num();
		aiMes->mBones = new aiBone*[mesh.Bones.Num()];
		auto aiBonArray = new aiBone[mesh.Bones.Num()]();
		for (size_t b = 0; b < mesh.Bones.Num(); b++)
		{
			auto& bone = mesh.Bones[b];
			auto aiBon = aiMes->mBones[b] = &aiBonArray[b];
			
			aiBon->mName = NontaoImportExportUtils::GetString(bone.Name);
			NontaoImportExportUtils::GetMatrix(bone.OffsetMatrix, aiBon->mOffsetMatrix);
			if (bone.Weights.Num()>0) {
				aiBon->mNumWeights = bone.Weights.Num();
				aiBon->mWeights = new aiVertexWeight[bone.Weights.Num()];
				for (size_t w = 0; w < bone.Weights.Num(); w++)
				{
					auto& weight = bone.Weights[w];
					auto& aiWei = aiBon->mWeights[w];
					aiWei.mVertexId = weight.VertexId;
					aiWei.mWeight = weight.Weight;
				}			
			}
		}


		aiMes->mNumAnimMeshes = mesh.AnimMeshes.Num();
		aiMes->mAnimMeshes = new aiAnimMesh*[mesh.AnimMeshes.Num()];
		auto aiAnimMeshArray = new aiAnimMesh[mesh.AnimMeshes.Num()]();
		for (size_t a = 0; a < mesh.AnimMeshes.Num(); a++)
		{
			auto& animMesh = mesh.AnimMeshes[a];
			auto aiAnimMes = aiMes->mAnimMeshes[a] = &aiAnimMeshArray[a];

			aiAnimMes->mName = aiString(std::string(TCHAR_TO_UTF8(*animMesh.Name)));
			aiAnimMes->mWeight = animMesh.Weight;

			aiAnimMes->mNumVertices = animMesh.Vertices.Num();
			aiAnimMes->mVertices = new aiVector3D[animMesh.Vertices.Num()];
			aiAnimMes->mNormals = new aiVector3D[animMesh.Vertices.Num()];
			if (aiMes->HasTangentsAndBitangents()) {
				aiAnimMes->mTangents = new aiVector3D[animMesh.Vertices.Num()];
				//aiAnimMes.mBitangents = new aiVector3D[animMesh.Vertices.Num()];
			}

			for (size_t c = 0; c < animMesh.Colors.Num() && c < AI_MAX_NUMBER_OF_COLOR_SETS; c++)
			{
				if (animMesh.Colors[c].Array.Num() > 0) {
					aiAnimMes->mColors[c] = new aiColor4D[animMesh.Vertices.Num()];
				}
			}

			for (size_t uv = 0; uv < animMesh.UVs.Num() && uv < AI_MAX_NUMBER_OF_TEXTURECOORDS; uv++)
			{
				if (animMesh.UVs[uv].Array.Num() > 0) {
					aiAnimMes->mTextureCoords[uv] = new aiVector3D[animMesh.Vertices.Num()];
				}
			}


			for (size_t v = 0; v < animMesh.Vertices.Num(); v++)
			{
				NontaoImportExportUtils::GetVector(animMesh.Vertices[v], aiMes->mVertices[v]);
				NontaoImportExportUtils::GetVector(animMesh.Normals[v], aiMes->mNormals[v]);
				if (aiMes->HasTangentsAndBitangents()) {
					NontaoImportExportUtils::GetVector(animMesh.Tangents[v], aiMes->mTangents[v]);
				}

				for (size_t c = 0; c < animMesh.Colors.Num() && c < AI_MAX_NUMBER_OF_COLOR_SETS; c++)
				{
					if (animMesh.Colors[c].Array.Num() > 0) {
						NontaoImportExportUtils::GetColor(animMesh.Colors[c].Array[v], aiMes->mColors[c][v]);
					}
				}

				for (size_t uv = 0; uv < animMesh.UVs.Num() && uv < AI_MAX_NUMBER_OF_TEXTURECOORDS; uv++)
				{
					if (animMesh.UVs[uv].Array.Num() > 0) {
						NontaoImportExportUtils::GetVector(animMesh.UVs[uv].Array[v], aiMes->mTextureCoords[uv][v]);
					}
				}
			}
		}
	}

	
	return true;
}

int UNontaoExporter::ParseLights(const TArray<FNontaoLight>& Lights) {

	mScene->mNumLights = Lights.Num();
	mScene->mLights = new aiLight*[Lights.Num()];
	auto aiLigArray = new aiLight[Lights.Num()]();
	for (size_t l = 0; l < Lights.Num(); l++)
	{
		auto& light = Lights[l];
		auto aiLig = mScene->mLights[l] = &aiLigArray[l];

		aiLig->mName= NontaoImportExportUtils::GetString(light.Name);
		aiLig->mType = (aiLightSourceType)light.Type;
		aiLig->mAngleInnerCone = light.AngleInnerCone;
		aiLig->mAngleOuterCone = light.AngleOuterCone;
		aiLig->mAttenuationLinear = light.AttenuationLinear;
		aiLig->mAttenuationConstant = light.AttenuationConstant;
		aiLig->mAttenuationQuadratic = light.AttenuationQuadratic;

		NontaoImportExportUtils::GetColor(light.ColorAmbient, aiLig->mColorAmbient);
		NontaoImportExportUtils::GetColor(light.ColorDiffuse, aiLig->mColorDiffuse);
		NontaoImportExportUtils::GetColor(light.ColorSpecular, aiLig->mColorSpecular);
		NontaoImportExportUtils::GetVector(light.Up, aiLig->mUp);
		NontaoImportExportUtils::GetVector(light.Position, aiLig->mPosition);
		NontaoImportExportUtils::GetVector(light.Direction, aiLig->mDirection);
	}

	return true;
}

int UNontaoExporter::ParseCameras(const TArray<FNontaoCamera>& Cameras) {

	mScene->mNumCameras = Cameras.Num();
	mScene->mCameras = new aiCamera*[Cameras.Num()];
	auto camArray = new aiCamera[Cameras.Num()]();
	for (size_t c = 0; c < Cameras.Num(); c++)
	{
		auto& camera = Cameras[c];
		auto aiCam = mScene->mCameras[c] = &camArray[c];

		aiCam->mName = NontaoImportExportUtils::GetString(camera.Name);
		aiCam->mAspect = camera.Aspect;
		aiCam->mClipPlaneFar = camera.ClipPlaneFar;
		aiCam->mClipPlaneNear = camera.ClipPlaneNear;
		aiCam->mHorizontalFOV = camera.HorizontalFOV;

		NontaoImportExportUtils::GetVector(camera.Position, aiCam->mPosition);
		NontaoImportExportUtils::GetVector(camera.LookAt, aiCam->mLookAt);
		NontaoImportExportUtils::GetVector(camera.Up, aiCam->mUp);
	}


	return true;
}

int UNontaoExporter::ParseAnimations(const TArray<FNontaoAnimation>& Animations) {
	
	return true;
}

int UNontaoExporter::ParseNodes(const TArray<FNontaoNode>& Nodes) {

	TArray<aiNode*> aiNodeArray;
	for (size_t n = 0; n < Nodes.Num(); n++)
	{
		auto& node = Nodes[n];
		auto aiNod = new aiNode();
		aiNodeArray.Add(aiNod);

		aiNod->mName = aiString(std::string(TCHAR_TO_UTF8(*node.Name)));
		aiNod->mParent = nullptr;
		aiNod->mNumChildren = 0;
		aiNod->mNumMeshes = node.Meshes.Num();
		aiNod->mMeshes = new unsigned int[node.Meshes.Num()]();
		for (size_t m = 0; m < node.Meshes.Num(); m++)
		{
			aiNod->mMeshes[m] = node.Meshes[m];
		}

		NontaoImportExportUtils::GetMetadata(node.Metas, aiNod->mMetaData);

		aiNod->mTransformation = aiMatrix4x4();

		if (node.Parent == -1) {
			mScene->mRootNode = aiNod;
		}
		else {
			auto parent = aiNodeArray[node.Parent];
			aiNod->mParent = parent;
			parent->addChildren(1, &aiNod);
		}
	}
	
	return true;
}


//bool UNontaoExporter::ExportWithDialog(const FNontaoScene& Scene)
//{
//	FString Title;
//	FString FileTypes;
//	FString FileFormatID = FString::Printf(TEXT("fbx"));
//	TArray<FString> OutFilenames;
//
//	auto exporter = Assimp::Exporter();
//	int n = exporter.GetExportFormatCount();
//	for (int i = 0; i < n; i++) {
//		const aiExportFormatDesc* formatDescription = exporter.GetExportFormatDescription(i);
//		FileTypes += FString::Printf(TEXT("|%s(%s)|*.%s"),
//			UTF8_TO_TCHAR(formatDescription->description),
//			UTF8_TO_TCHAR(formatDescription->id),
//			UTF8_TO_TCHAR(formatDescription->fileExtension));
//	}
//
//	FileTypes = FileTypes.Mid(1);
//
//	if (UNontaoImportExportBPLib::SaveFileDialog(Title, FileTypes, OutFilenames)) {
//		auto& file = OutFilenames[0];
//		return Export(Scene, FileFormatID, file);
//	}
//
//	return false;
//}


bool UNontaoExporter::Export(const FNontaoScene& Scene, const FString& FormatId, const FString& File)
{	
	auto exporter = Assimp::Exporter();
	Parse(Scene);
	unsigned int pFlags = aiProcess_MakeLeftHanded | aiProcess_CalcTangentSpace | aiProcess_GenSmoothNormals | aiProcess_OptimizeMeshes;

	//aiReturn Export(const aiScene* pScene, const char* pFormatId, const char* pPath,
	//	unsigned int pPreprocessing = 0u, const ExportProperties* pProperties = nullptr);
	//aiReturn Export(const aiScene* pScene, const std::string& pFormatId, const std::string& pPath,
	//	unsigned int pPreprocessing = 0u, const ExportProperties* pProperties = nullptr);	
	auto result = exporter.Export(mScene.get(), TCHAR_TO_UTF8(*FormatId), TCHAR_TO_UTF8(*File), pFlags);
	
	return result == aiReturn::aiReturn_SUCCESS;
}
