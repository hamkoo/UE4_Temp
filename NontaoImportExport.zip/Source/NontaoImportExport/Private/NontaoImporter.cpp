// Copyright 2016-2020 Nontao. All Rights Reserved.


#include "NontaoImporter.h"

#include "Misc/Paths.h"

#include "NontaoImportExportUtils.h"

//...
#include "assimp/include/assimp/config.h"

#include <functional>


UNontaoImporter::UNontaoImporter(const FObjectInitializer& ObjectInitializer)
	: UObject(ObjectInitializer)
{
	UE_LOG(LogTemp, Warning, TEXT("UNontaoImporter::UNontaoImporter()"));
}

UNontaoImporter::~UNontaoImporter() {
	UE_LOG(LogTemp, Warning, TEXT("UNontaoImporter::~UNontaoImporter()"));
}

bool UNontaoImporter::LoadFile(const FString& File, const FNontaoImportOptions& ImportOptions) {

	this->FileName = File;

	if (File.IsEmpty()) {
		UE_LOG(LogTemp, Warning, TEXT("FileName is empty."));
		return false;
	}

	if (FPaths::FileExists(File) == false) {
		UE_LOG(LogTemp, Warning, TEXT("FileName is not exist."));
		return false;
	}

	Assimp::Importer importer;
	
	//if (AssimpImporter.IsValid()) 
	{
		const char* fileName = TCHAR_TO_UTF8(*File);
		unsigned int flags = aiProcess_Triangulate | aiProcess_MakeLeftHanded | aiProcess_CalcTangentSpace | aiProcess_GenSmoothNormals | aiProcess_OptimizeMeshes;

		//importer.SetPropertyBool(AI_CONFIG_IMPORT_FBX_PRESERVE_PIVOTS, false);
		const aiScene* scene = importer.ReadFile(fileName, flags);

		if (!scene) {
			UE_LOG(LogTemp, Warning, TEXT("Failed to load file: %s."), *File);
			return false;
		}

		Parse(scene);

		return true;
	}

	return true;
}

bool UNontaoImporter::LoadBuffer(const TArray<uint8>& Buffer, const FNontaoImportOptions& ImportOptions) {

	return true;
}

bool UNontaoImporter::LoadFromMemory(const FNontaoImportOptions& ImportOptions) {

	return true;
}

void UNontaoImporter::Clear() {
	NontaoScene.Reset();
}

bool UNontaoImporter::Parse(const aiScene* Scene) {
	
	Clear();

	if (Scene) {
		ParseScene(Scene);
		ParseMetas(Scene);
		ParseTextures(Scene);
		ParseMaterials(Scene);
		ParseMeshes(Scene);
		ParseLights(Scene);
		ParseCameras(Scene);
		ParseAnimations(Scene);

		ParseNodes(Scene);

		return true;
	}

	return false;
}

bool UNontaoImporter::ParseScene(const aiScene* Scene) {

	return true;
}

int UNontaoImporter::ParseMetas(const aiScene* Scene) {

	if (Scene->mMetaData && Scene->mMetaData->mNumProperties > 0) {

		auto metaData = Scene->mMetaData;

		if (1) {
			NontaoScene.Metas.SetNum(metaData->mNumProperties);
			for (size_t m = 0; m < metaData->mNumProperties; m++)
			{
				auto& key = metaData->mKeys[m];
				auto& aiValue = metaData->mValues[m];
				auto& meta = NontaoScene.Metas[m];

				meta.Name = NontaoImportExportUtils::GetString(key);
				meta.Type = (ENontaoDataType)aiValue.mType;

				switch (meta.Type)
				{
				case ENontaoDataType::Nontao_BOOL:
				{
					NontaoImportExportUtils::GetArray<int, bool>(meta.Data, aiValue.mData);
					break;
				}
				case ENontaoDataType::Nontao_INT32:
				{
					NontaoImportExportUtils::GetArray<int, int32>(meta.Data, aiValue.mData);
					break;				
				}

				case ENontaoDataType::Nontao_UINT64:
				{
					NontaoImportExportUtils::GetArray<int, uint64>(meta.Data, aiValue.mData);
					break;
				}

				case ENontaoDataType::Nontao_FLOAT:
				{
					NontaoImportExportUtils::GetArray<int, float>(meta.Data, aiValue.mData);
					break;
				}

				case ENontaoDataType::Nontao_DOUBLE:
				{
					NontaoImportExportUtils::GetArray<int, double>(meta.Data, aiValue.mData);
					break;
				}

				case ENontaoDataType::Nontao_STRING:
				{
					auto aiStr = (aiString*)aiValue.mData;
					NontaoImportExportUtils::GetArray<int>(meta.Data, aiStr->C_Str(), aiStr->length);
					break;
				}
				case ENontaoDataType::Nontao_VECTOR:
				{
					//NontaoImportExportUtils::GetArray<int, aiVector3D>(meta.Data, aiValue.mData);
					auto aiVec = (aiVector3D*)aiValue.mData;
					FVector vec(aiVec->x, aiVec->y, aiVec->z);
					NontaoImportExportUtils::GetArray<int, FVector>(meta.Data, &vec);
					break;
				}
				default:
					break;
				}
			}
		}		
	}

	return NontaoScene.Metas.Num();
}

int UNontaoImporter::ParseTextures(const aiScene* Scene) {

	NontaoScene.Textures.SetNum(Scene->mNumTextures);
	for (size_t t = 0; t < Scene->mNumTextures; t++)
	{
		auto aiTex = Scene->mTextures[t];
		auto& texture = NontaoScene.Textures[t];

		texture.FileName = NontaoImportExportUtils::GetString(aiTex->mFilename);
		texture.Width = aiTex->mWidth;
		texture.Height = aiTex->mHeight;
		texture.FormatHint = FString(UTF8_TO_TCHAR(aiTex->achFormatHint));

		NontaoImportExportUtils::GetArray<uint8>(texture.Data, aiTex->pcData, aiTex->mWidth);
	}

	return NontaoScene.Textures.Num();
}

int UNontaoImporter::ParseMaterials(const aiScene* Scene) {
	
	NontaoScene.Materials.SetNum(Scene->mNumMaterials);
	for (size_t m = 0; m < Scene->mNumMaterials; m++)
	{
		auto aiMat = Scene->mMaterials[m];
		auto& material = NontaoScene.Materials[m];

		material.Name = NontaoImportExportUtils::GetString(aiMat->GetName());
		material.NumAllocated = aiMat->mNumAllocated;

		material.Properties.SetNum(aiMat->mNumProperties);
		for (size_t p = 0; p < aiMat->mNumProperties; p++)
		{
			auto aiPro = aiMat->mProperties[p];
			auto& prop = material.Properties[p];

			prop.Name = NontaoImportExportUtils::GetString(aiPro->mKey);
			prop.Type = (ENontaoPropertyType)aiPro->mType;
			prop.Semantic = aiPro->mSemantic;
			prop.Index = aiPro->mIndex;

			NontaoImportExportUtils::GetArray<int32>(prop.Data, aiPro->mData, aiPro->mDataLength);
		}
	}

	return NontaoScene.Materials.Num();
}

int UNontaoImporter::ParseMeshes(const aiScene* Scene) {
	
	NontaoScene.Meshes.SetNum(Scene->mNumMeshes);
	for (size_t m = 0; m < Scene->mNumMeshes; m++)
	{
		auto aiMes = Scene->mMeshes[m];
		auto& mesh = NontaoScene.Meshes[m];
		mesh.Name = NontaoImportExportUtils::GetString(aiMes->mName);
		mesh.PrimitiveType = aiMes->mPrimitiveTypes;
		mesh.MaterialIndex = aiMes->mMaterialIndex;
		mesh.Method = aiMes->mMethod;

		mesh.Vertices.SetNum(aiMes->mNumVertices);
		mesh.Normals.SetNum(aiMes->mNumVertices);
		mesh.Tangents.SetNum(aiMes->mNumVertices);
		mesh.NumUVComponents.SetNum(AI_MAX_NUMBER_OF_TEXTURECOORDS);
		NontaoImportExportUtils::GetVector(aiMes->mAABB.mMax, mesh.Box.Max);
		NontaoImportExportUtils::GetVector(aiMes->mAABB.mMin, mesh.Box.Min);

		mesh.UVs.SetNum(AI_MAX_NUMBER_OF_TEXTURECOORDS);
		for (size_t i = 0; i < AI_MAX_NUMBER_OF_TEXTURECOORDS; i++)
		{
			if (aiMes->HasTextureCoords(i)) {
				//mesh.UVs.SetNum(i+1);
				mesh.UVs[i].Array.SetNum(aiMes->mNumVertices);
			}
			mesh.NumUVComponents[i] = aiMes->mNumUVComponents[i];
		}

		mesh.VertexColors.SetNum(AI_MAX_NUMBER_OF_COLOR_SETS);
		for (size_t c = 0; c < AI_MAX_NUMBER_OF_COLOR_SETS; c++)
		{
			if (aiMes->HasVertexColors(c)) {
				//mesh.VertexColors.SetNum(c + 1);
				mesh.VertexColors[c].Array.SetNum(aiMes->mNumVertices);
			}
		}
		
		for (size_t v = 0; v < aiMes->mNumVertices; v++)
		{
			NontaoImportExportUtils::GetVector(aiMes->mVertices[v], mesh.Vertices[v]);
			for (size_t c = 0; c < mesh.VertexColors.Num(); c++) {
				//C_STRUCT aiColor4D* mColors[AI_MAX_NUMBER_OF_COLOR_SETS];
				if (aiMes->HasVertexColors(c)) {
					NontaoImportExportUtils::GetLinearColor(aiMes->mColors[c][v], mesh.VertexColors[c].Array[v]);
				}
				//else {
				//	mesh.VertexColors[c].Array[v] = FLinearColor::White;
				//}
			}


			if (aiMes->HasNormals()) {
				NontaoImportExportUtils::GetVector(aiMes->mNormals[v], mesh.Normals[v]);
			}
			else
			{
				mesh.Normals[v] = FVector::ZeroVector;
			}

			if (aiMes->HasTangentsAndBitangents()) {
				NontaoImportExportUtils::GetVector(aiMes->mTangents[v], mesh.Tangents[v]);
			}
			else
			{
				mesh.Tangents[v] = FVector::ZeroVector;
			}

			for (size_t i = 0; i < AI_MAX_NUMBER_OF_TEXTURECOORDS; i++)
			{
				if (aiMes->HasTextureCoords(i)) {
					auto& aiUV = aiMes->mTextureCoords[i][v];
					auto& uv = mesh.UVs[i].Array[v];
					//NontaoImportExportUtils::GetVector2D(aiUV, uv);
					uv.X = aiUV.x;
					uv.Y = -aiUV.y;
				}
			}
		}

		for (size_t f = 0; f < aiMes->mNumFaces; f++)
		{
			auto& aiFac = aiMes->mFaces[f];

			if (aiFac.mNumIndices == 3) {
				mesh.Triangles.Add(aiFac.mIndices[0]);
				mesh.Triangles.Add(aiFac.mIndices[1]);
				mesh.Triangles.Add(aiFac.mIndices[2]);
			}

			if (aiFac.mNumIndices == 4) {
				mesh.Triangles.Add(aiFac.mIndices[0]);
				mesh.Triangles.Add(aiFac.mIndices[1]);
				mesh.Triangles.Add(aiFac.mIndices[2]);

				mesh.Triangles.Add(aiFac.mIndices[2]);
				mesh.Triangles.Add(aiFac.mIndices[3]);
				mesh.Triangles.Add(aiFac.mIndices[0]);
			}
		}

		mesh.AnimMeshes.SetNum(aiMes->mNumAnimMeshes);
		for (size_t a = 0; a < aiMes->mNumAnimMeshes; a++)
		{
			auto& animMesh = mesh.AnimMeshes[a];
			auto aiAni = aiMes->mAnimMeshes[a];
			animMesh.Name = NontaoImportExportUtils::GetString(aiAni->mName);
			animMesh.Colors.SetNum(8);

			for (size_t c = 0; c < AI_MAX_NUMBER_OF_COLOR_SETS; c++)
			{
				if (aiAni->HasVertexColors(c)) {
					animMesh.Colors[c].Array.SetNum(aiAni->mNumVertices);
				}
			}

			animMesh.Vertices.SetNum(aiAni->mNumVertices);
			animMesh.Normals.SetNum(aiAni->mNumVertices);
			if (aiAni->HasTangentsAndBitangents())
			{
				animMesh.Tangents.SetNum(aiAni->mNumVertices);
				animMesh.Bitangents.SetNum(aiAni->mNumVertices);
			}

			for (size_t iV = 0; iV < aiAni->mNumVertices; iV++)
			{
				NontaoImportExportUtils::GetVector(aiAni->mVertices[iV], animMesh.Vertices[iV]);
				NontaoImportExportUtils::GetVector(aiAni->mNormals[iV], animMesh.Normals[iV]);
				if (aiAni->HasTangentsAndBitangents()) {
					NontaoImportExportUtils::GetVector(aiAni->mTangents[iV], animMesh.Tangents[iV]);
					NontaoImportExportUtils::GetVector(aiAni->mBitangents[iV], animMesh.Bitangents[iV]);
				}

				for (size_t c = 0; c < AI_MAX_NUMBER_OF_COLOR_SETS; c++)
				{
					if (aiAni->HasVertexColors(c)) {
						NontaoImportExportUtils::GetLinearColor(aiAni->mColors[c][iV], animMesh.Colors[c].Array[iV]);
					}
				}
			}
		}

		mesh.Bones.SetNum(aiMes->mNumBones);
		for (size_t b = 0; b < aiMes->mNumBones; b++)
		{
			auto aiBon = aiMes->mBones[b];
			auto& bone = mesh.Bones[b];

			bone.Name = NontaoImportExportUtils::GetString(aiBon->mName);
			NontaoImportExportUtils::GetMatrix(aiBon->mOffsetMatrix, bone.OffsetMatrix);
			bone.Weights.SetNum(aiBon->mNumWeights);

			for (size_t w = 0; w < aiBon->mNumWeights; w++)
			{
				auto& aiWei = aiBon->mWeights[w];
				auto& weight = bone.Weights[w];
				weight.VertexId = aiWei.mVertexId;
				weight.Weight = aiWei.mWeight;
			}
		}
	}

	return NontaoScene.Meshes.Num();
}

int UNontaoImporter::ParseLights(const aiScene* Scene) {

	NontaoScene.Lights.SetNum(Scene->mNumLights);
	for (size_t l = 0; l < Scene->mNumLights; l++)
	{
		auto aiLig = Scene->mLights[l];
		auto& light = NontaoScene.Lights[l];

		light.Name = NontaoImportExportUtils::GetString(aiLig->mName);
		light.Type = (ENontaoLightSourceType)aiLig->mType;
		light.AngleInnerCone = aiLig->mAngleInnerCone;
		light.AngleOuterCone = aiLig->mAngleOuterCone;
		light.AttenuationLinear = aiLig->mAttenuationLinear;
		light.AttenuationConstant = aiLig->mAttenuationConstant;
		light.AttenuationQuadratic = aiLig->mAttenuationQuadratic;

		NontaoImportExportUtils::GetLinearColor(aiLig->mColorAmbient, light.ColorAmbient);
		NontaoImportExportUtils::GetLinearColor(aiLig->mColorDiffuse, light.ColorDiffuse);
		NontaoImportExportUtils::GetLinearColor(aiLig->mColorSpecular, light.ColorSpecular);
		NontaoImportExportUtils::GetVector(aiLig->mUp, light.Up);
		NontaoImportExportUtils::GetVector(aiLig->mPosition, light.Position);
		NontaoImportExportUtils::GetVector(aiLig->mDirection, light.Direction);
	}

	return NontaoScene.Lights.Num();
}

int UNontaoImporter::ParseCameras(const aiScene* Scene) {

	NontaoScene.Cameras.SetNum(Scene->mNumCameras);
	for (size_t c = 0; c < Scene->mNumCameras; c++)
	{
		auto aiCam = Scene->mCameras[c];
		auto& camera = NontaoScene.Cameras[c];

		camera.Name = NontaoImportExportUtils::GetString(aiCam->mName);
		camera.Aspect = aiCam->mAspect;
		camera.ClipPlaneFar = aiCam->mClipPlaneFar;
		camera.ClipPlaneNear = aiCam->mClipPlaneNear;
		camera.HorizontalFOV = aiCam->mHorizontalFOV;

		NontaoImportExportUtils::GetVector(aiCam->mPosition, camera.Position);
		NontaoImportExportUtils::GetVector(aiCam->mLookAt, camera.LookAt);
		NontaoImportExportUtils::GetVector(aiCam->mUp, camera.Up);
	}

	return NontaoScene.Cameras.Num();
}

int UNontaoImporter::ParseAnimations(const aiScene* Scene) {

	NontaoScene.Animations.SetNum(Scene->mNumAnimations);
	for (size_t a = 0; a < Scene->mNumAnimations; a++)
	{
		auto aiAni = Scene->mAnimations[a];
		auto& animation = NontaoScene.Animations[a];
		animation.Name = NontaoImportExportUtils::GetString(aiAni->mName);
		animation.Druation = aiAni->mDuration;
		animation.TicksPerSecond = aiAni->mTicksPerSecond;

		animation.Channels.SetNum(aiAni->mNumChannels);
		animation.MeshChannels.SetNum(aiAni->mNumMeshChannels);
		animation.MorphMeshChannels.SetNum(aiAni->mNumMorphMeshChannels);

		for (size_t c = 0; c < aiAni->mNumChannels; c++)
		{
			auto aiChl = aiAni->mChannels[c];
			auto& channel = animation.Channels[c];
			channel.Name = NontaoImportExportUtils::GetString(aiChl->mNodeName);
			channel.PostState = aiChl->mPostState;
			channel.PreState = aiChl->mPreState;
			channel.PositionKeys.SetNum(aiChl->mNumPositionKeys);
			channel.RotationKeys.SetNum(aiChl->mNumRotationKeys);
			channel.ScalingKeys.SetNum(aiChl->mNumScalingKeys);

			for (size_t p = 0; p < aiChl->mNumPositionKeys; p++)
			{
				auto& aiKey = aiChl->mPositionKeys[p];
				auto& key = channel.PositionKeys[p];
				key.Time = aiKey.mTime;
				NontaoImportExportUtils::GetVector(aiKey.mValue, key.Value);
			}

			for (size_t r = 0; r < aiChl->mNumRotationKeys; r++)
			{
				auto& aiKey = aiChl->mRotationKeys[r];
				auto& key = channel.RotationKeys[r];
				key.Time = aiKey.mTime;
				NontaoImportExportUtils::GetQuaternion(aiKey.mValue, key.Value);
			}

			for (size_t s = 0; s < aiChl->mNumScalingKeys; s++)
			{
				auto& aiKey = aiChl->mScalingKeys[s];
				auto& key = channel.ScalingKeys[s];
				key.Time = aiKey.mTime;
				NontaoImportExportUtils::GetVector(aiKey.mValue, key.Value);
			}
		}
	}

	return NontaoScene.Animations.Num();
}

int UNontaoImporter::ParseNodes(const aiScene* Scene) {

	////auto recursiveFunc2 = std::make_shared<std::unique_ptr<std::function<void(const aiNode*, UNontaoNode*, UNontaoNode*)> >>();
	////*recursiveFunc2 = std::make_unique<std::function<void(const aiNode*, UNontaoNode*, UNontaoNode*)>>(
	////	[=](const aiNode* aiNod, UNontaoNode* Node = nullptr, UNontaoNode* Parent = nullptr) {
	////	
	////	//Node->Metas.SetNum(aiNod->m);
	////	Node->Name = NontaoImportExportUtils::GetString(aiNod->mName);
	////	Node->Transform = FTransform(NontaoImportExportUtils::GetMatrix(aiNod->mTransformation));
	////	Node->Parent = Parent;
	////	
	////	Node->Meshes.SetNum(aiNod->mNumMeshes);
	////	for (size_t i = 0; i < aiNod->mNumMeshes; i++)
	////	{
	////		Node->Meshes[i] = aiNod->mMeshes[i];
	////	}

	////	for (size_t i = 0; i < aiNod->mNumChildren; i++)
	////	{
	////		auto child = NewObject<UNontaoNode>();
	////		Node->Children.Add(child);
	////		(**recursiveFunc2)(aiNod->mChildren[i], child, Node);
	////	}
	////	}
	////);

	////(**recursiveFunc2)(Scene->mRootNode, NontaoScene.Root, nullptr);


	auto recursiveFunc = std::make_shared<std::unique_ptr<std::function<void(TArray<FNontaoNode>&, const aiNode*, const int)> >>();
	*recursiveFunc = std::make_unique<std::function<void(TArray<FNontaoNode>&, const aiNode*, const int)>>(
		[=](TArray<FNontaoNode>& Nodes, const aiNode* aiNod, const int ParentIndex = -1) {
		
		auto index = Nodes.Num();
		Nodes.SetNum(index + 1);
		auto& Node = Nodes[index];
		Node.Name = NontaoImportExportUtils::GetString(aiNod->mName);
		Node.Transform = FTransform(NontaoImportExportUtils::GetMatrix(aiNod->mTransformation));
		Node.Parent = ParentIndex;
		Node.Meshes.SetNum(aiNod->mNumMeshes);
		for (size_t i = 0; i < aiNod->mNumMeshes; i++)
		{
			Node.Meshes[i] = aiNod->mMeshes[i];
		}

		Node.Children.SetNum(aiNod->mNumChildren);
		for (size_t i = 0; i < aiNod->mNumChildren; i++)
		{
			auto& child = Node.Children[i];
			(**recursiveFunc)(Nodes, aiNod->mChildren[i], index);
		}
	}
	);

	(**recursiveFunc)(NontaoScene.Nodes, Scene->mRootNode, -1);

	return 0;
}

const FString UNontaoImporter::GetDetails() {
	FString rst;

	rst += FString("Scene\r");
	rst += FString::Printf(TEXT("\tMatrix4Axis='%s'\r"), *NontaoScene.Matrix4Axis.ToString());

	rst += FString::Printf(TEXT("Animations.Num=%d\r"),NontaoScene.Animations.Num());
	for (size_t i = 0; i < NontaoScene.Animations.Num(); i++)
	{
		rst += FString::Printf(TEXT("\t[%d]='%s'\r"), i, *NontaoScene.Animations[i].Name);
	}

	rst += FString::Printf(TEXT("Cameras.Num=%d\r"), NontaoScene.Cameras.Num());
	for (size_t i = 0; i < NontaoScene.Cameras.Num(); i++)
	{
		rst += FString::Printf(TEXT("\t[%d]='%s'\r"), i, *NontaoScene.Cameras[i].Name);
	}

	rst += FString::Printf(TEXT("Lights.Num=%d\r"), NontaoScene.Lights.Num());
	for (size_t i = 0; i < NontaoScene.Lights.Num(); i++)
	{
		rst += FString::Printf(TEXT("\t[%d]='%s'\r"), i, *NontaoScene.Lights[i].Name);
	}

	rst += FString::Printf(TEXT("Materials.Num=%d\r"), NontaoScene.Materials.Num());
	for (size_t i = 0; i < NontaoScene.Materials.Num(); i++)
	{
		rst += FString::Printf(TEXT("\t[%d]='%s'\r"), i, *NontaoScene.Materials[i].Name);
	}

	rst += FString::Printf(TEXT("Meshes.Num=%d\r"), NontaoScene.Meshes.Num());
	for (size_t i = 0; i < NontaoScene.Meshes.Num(); i++)
	{
		rst += FString::Printf(TEXT("\t[%d]='%s',vertexs=%d,triangles=%d\r"), i, 
			*NontaoScene.Meshes[i].Name, 
			NontaoScene.Meshes[i].Vertices.Num(),
			NontaoScene.Meshes[i].Triangles.Num()
		);
	}

	rst += FString::Printf(TEXT("Textures.Num=%d\r"), NontaoScene.Textures.Num());
	for (size_t i = 0; i < NontaoScene.Textures.Num(); i++)
	{
		rst += FString::Printf(TEXT("\t[%d]='%s'\r"), i, *NontaoScene.Textures[i].FileName);
	}

	return rst;
}


const FString UNontaoImporter::GetTextureJson(const FNontaoTexture& Value) {
	FString rst;

	rst += FString(TEXT("Texture:{\r"));
	rst += FString::Printf(TEXT("\tFileName:'%s',\r"), *Value.FileName);
	rst += FString::Printf(TEXT("\tFormatHint:'%s',\r"), *Value.FormatHint);
	rst += FString::Printf(TEXT("\tWidth:%d,\r"), Value.Width);
	rst += FString::Printf(TEXT("\tHeight:%d,\r"), Value.Height);
	rst += FString(TEXT("}\r"));

	return rst;
}


const FString UNontaoImporter::GetMaterialJson(const FNontaoMaterial& Value) {
	FString rst;

	rst += FString(TEXT("Material:{\r"));
	rst += FString::Printf(TEXT("\tName:'%s',\r"), *Value.Name);
	rst += FString::Printf(TEXT("\tNumAllocated:%d,\r"), Value.NumAllocated);
	rst += FString::Printf(TEXT("\tPropertiesNum:%d,\r"), Value.Properties.Num());
	rst += FString(TEXT("}\r"));

	return rst;
}

const FString UNontaoImporter::GetMeshJson(const FNontaoMesh& Value) {
	FString rst;

	rst += FString(TEXT("Mesh:{\r"));
	rst += FString::Printf(TEXT("\tName:'%s',\r"), *Value.Name);
	rst += FString::Printf(TEXT("\tAnimMeshesNum:%d,\r"), Value.AnimMeshes.Num());
	rst += FString::Printf(TEXT("\tBonesNum:%d,\r"), Value.Bones.Num());
	rst += FString::Printf(TEXT("\tMaterialIndex:%d,\r"), Value.MaterialIndex);
	rst += FString::Printf(TEXT("\tMethod:%d,\r"), Value.Method);
	rst += FString::Printf(TEXT("\tNormalsNum:%d,\r"), Value.Normals.Num());
	rst += FString::Printf(TEXT("\tPrimitiveTypes:%d,\r"), Value.PrimitiveType);
	rst += FString::Printf(TEXT("\tTangentsNum:%d,\r"), Value.Tangents.Num());
	rst += FString::Printf(TEXT("\tTrianglesNum:%d,\r"), Value.Triangles.Num());
	rst += FString::Printf(TEXT("\tUVs0Num:%d,\r"), Value.UVs[0].Array.Num());
	rst += FString::Printf(TEXT("\tVertexColorsNum:%d,\r"), Value.VertexColors.Num());
	rst += FString::Printf(TEXT("\tVerticesNum:%d,\r"), Value.Vertices.Num());
	rst += FString(TEXT("}\r"));

	return rst;
}

const FString UNontaoImporter::GetLightJson(const FNontaoLight& Value) {
	FString rst;

	rst += FString(TEXT("Light:{\r"));
	rst += FString::Printf(TEXT("\tName:'%s',\r"), *Value.Name);
	rst += FString::Printf(TEXT("\tAngleInnerCone:%f,\r"), Value.AngleInnerCone);
	rst += FString::Printf(TEXT("\tAngleOuterCone:%f,\r"), Value.AngleOuterCone);
	rst += FString::Printf(TEXT("\tAttenuationConstant:%f,\r"), Value.AttenuationConstant);
	rst += FString::Printf(TEXT("\tAttenuationLinear:%f,\r"), Value.AttenuationLinear);
	rst += FString::Printf(TEXT("\tAttenuationQuadratic:%f,\r"), Value.AttenuationQuadratic);
	rst += FString::Printf(TEXT("\tColorAmbient:'%s',\r"), *Value.ColorAmbient.ToString());
	rst += FString::Printf(TEXT("\tColorDiffuse:'%s',\r"), *Value.ColorDiffuse.ToString());
	rst += FString::Printf(TEXT("\tColorSpecular:'%s',\r"), *Value.ColorSpecular.ToString());
	rst += FString::Printf(TEXT("\tDirection:'%s',\r"), *Value.Direction.ToString());
	rst += FString::Printf(TEXT("\tPosition:'%s',\r"), *Value.Position.ToString());
	rst += FString::Printf(TEXT("\tUp:'%s',\r"), *Value.Up.ToString());
	rst += FString::Printf(TEXT("\tSize:'%s',\r"), *Value.Size.ToString());
	rst += FString::Printf(TEXT("\tType:%d,\r"), Value.Type);
	rst += FString(TEXT("}\r"));

	return rst;
}

const FString UNontaoImporter::GetCameraJson(const FNontaoCamera& Value) {
	FString rst;

	rst += FString(TEXT("Camera:{\r"));
	rst += FString::Printf(TEXT("\tName:'%s',\r"), *Value.Name);
	rst += FString::Printf(TEXT("\tAspect:%f,\r"), Value.Aspect);
	rst += FString::Printf(TEXT("\tClipPlaneFar:%f,\r"), Value.ClipPlaneFar);
	rst += FString::Printf(TEXT("\tClipPlaneNear:%f,\r"), Value.ClipPlaneNear);
	rst += FString::Printf(TEXT("\tHorizontalFOV:%f,\r"), Value.HorizontalFOV);
	rst += FString::Printf(TEXT("\tLookAt:'%s',\r"), *Value.LookAt.ToString());
	rst += FString::Printf(TEXT("\tPosition:'%s',\r"), *Value.Position.ToString());
	rst += FString::Printf(TEXT("\tUp:'%s',\r"), *Value.Up.ToString());
	rst += FString(TEXT("}\r"));

	return rst;
}

const FString UNontaoImporter::GetAnimationJson(const FNontaoAnimation& Value) {
	FString rst;

	rst += FString(TEXT("Animation:{\r"));
	rst += FString::Printf(TEXT("\tName:'%s',\r"), *Value.Name);	
	rst += FString::Printf(TEXT("\tChannelsNum:%d,\r"), Value.Channels.Num());
	rst += FString::Printf(TEXT("\tDruation:%f,\r"), Value.Druation);
	rst += FString::Printf(TEXT("\tTicksPerSecond:%f,\r"), Value.TicksPerSecond);
	rst += FString::Printf(TEXT("\tMeshChannelsNum:%d,\r"), Value.MeshChannels.Num());
	rst += FString::Printf(TEXT("\tMorphMeshChannelsNum:%d,\r"), Value.MorphMeshChannels.Num());
	rst += FString(TEXT("}\r"));

	return rst;
}

const FString UNontaoImporter::GetMetaJson(const FNontaoMeta& Value) {
	FString rst;

	return rst;
}


const FString UNontaoImporter::GetNodeJson(const FNontaoNode& Value) {
	FString rst;

	rst += FString(TEXT("Animation:{\r"));
	rst += FString::Printf(TEXT("\tName:'%s',\r"), *Value.Name);
	rst += FString::Printf(TEXT("\tChildrenNum:%d,\r"), Value.Children.Num());
	rst += FString::Printf(TEXT("\tMeshesNum:%d,\r"), Value.Meshes.Num());
	rst += FString::Printf(TEXT("\tMetasNum:%d,\r"), Value.Metas.Num());
	rst += FString::Printf(TEXT("\tParent:%d,\r"), Value.Parent);
	rst += FString::Printf(TEXT("\tTransform:'%s',\r"), *Value.Transform.ToString());
	rst += FString(TEXT("}\r"));

	return rst;
}