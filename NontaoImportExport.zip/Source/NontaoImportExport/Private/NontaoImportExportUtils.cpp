// Fill out your copyright notice in the Description page of Project Settings.


#include "NontaoImportExportUtils.h"

#include "NontaoImportExportStructs.h"

NontaoImportExportUtils::NontaoImportExportUtils()
{
}

NontaoImportExportUtils::~NontaoImportExportUtils()
{
}


FString NontaoImportExportUtils::GetTextureTypeString(const aiTextureType type) {

	std::string str;

	switch (type) {

		/** Dummy value.
		 *
		 *  No texture, but the value to be used as 'texture semantic'
		 *  (#aiMaterialProperty::mSemantic) for all material properties
		 *  *not* related to textures.
		 */
	case aiTextureType::aiTextureType_NONE:
		str = "NONE";
		break;

		/** LEGACY API MATERIALS
			* Legacy refers to materials which
			* Were originally implemented in the specifications around 2000.
			* These must never be removed, as most engines support them.
			*/

			/** The texture is combined with the result of the diffuse
			*  lighting equation.
			*/
	case aiTextureType::aiTextureType_DIFFUSE:
		str = "DIFFUSE";
		break;

		/** The texture is combined with the result of the specular
			*  lighting equation.
			*/
	case aiTextureType::aiTextureType_SPECULAR:
		str = "SPECULAR";
		break;

		/** The texture is combined with the result of the ambient
			*  lighting equation.
			*/
	case aiTextureType::aiTextureType_AMBIENT:
		str = "AMBIENT";
		break;

		/** The texture is added to the result of the lighting
			*  calculation. It isn't influenced by incoming light.
			*/
	case aiTextureType::aiTextureType_EMISSIVE:
		str = "EMISSIVE";
		break;

		/** The texture is a height map.
			*
			*  By convention, higher gray-scale values stand for
			*  higher elevations from the base height.
			*/
	case aiTextureType::aiTextureType_HEIGHT:
		str = "HEIGHT";
		break;

		/** The texture is a (tangent space) normal-map.
			*
			*  Again, there are several conventions for tangent-space
			*  normal maps. Assimp does (intentionally) not
			*  distinguish here.
			*/
	case aiTextureType::aiTextureType_NORMALS:
		str = "NORMALS";
		break;

		/** The texture defines the glossiness of the material.
			*
			*  The glossiness is in fact the exponent of the specular
			*  (phong) lighting equation. Usually there is a conversion
			*  function defined to map the linear color values in the
			*  texture to a suitable exponent. Have fun.
		*/
	case aiTextureType::aiTextureType_SHININESS:
		str = "SHININESS";
		break;

		/** The texture defines per-pixel opacity.
			*
			*  Usually 'white' means opaque and 'black' means
			*  'transparency'. Or quite the opposite. Have fun.
		*/
	case aiTextureType::aiTextureType_OPACITY:
		str = "OPACITY";
		break;

		/** Displacement texture
			*
			*  The exact purpose and format is application-dependent.
			*  Higher color values stand for higher vertex displacements.
		*/
	case aiTextureType::aiTextureType_DISPLACEMENT:
		str = "DISPLACEMENT";
		break;

		/** Lightmap texture (aka Ambient Occlusion)
			*
			*  Both 'Lightmaps' and dedicated 'ambient occlusion maps' are
			*  covered by this material property. The texture contains a
			*  scaling value for the final color value of a pixel. Its
			*  intensity is not affected by incoming light.
		*/
	case aiTextureType::aiTextureType_LIGHTMAP:
		str = "LIGHTMAP";
		break;

		/** Reflection texture
			*
			* Contains the color of a perfect mirror reflection.
			* Rarely used, almost never for real-time applications.
		*/
	case aiTextureType::aiTextureType_REFLECTION:
		str = "REFLECTION";
		break;

		/** PBR Materials
			* PBR definitions from maya and other modelling packages now use this standard.
			* This was originally introduced around 2012.
			* Support for this is in game engines like Godot, Unreal or Unity3D.
			* Modelling packages which use this are very common now.
			*/

	case aiTextureType::aiTextureType_BASE_COLOR:
		str = "BASE_COLOR";
		break;
	case aiTextureType::aiTextureType_NORMAL_CAMERA:
		str = "NORMAL_CAMERA";
		break;
	case aiTextureType::aiTextureType_EMISSION_COLOR:
		str = "EMISSION_COLOR";
		break;
	case aiTextureType::aiTextureType_METALNESS:
		str = "METALNESS";
		break;
	case aiTextureType::aiTextureType_DIFFUSE_ROUGHNESS:
		str = "ROUGHNESS";
		break;
	case aiTextureType::aiTextureType_AMBIENT_OCCLUSION:
		str = "OCCLUSION";
		break;

		/** Unknown texture
			*
			*  A texture reference that does not match any of the definitions
			*  above is considered to be 'unknown'. It is still imported,
			*  but is excluded from any further post-processing.
		*/
	case aiTextureType::aiTextureType_UNKNOWN:
	default:
		str = "UNKNOWN";
		break;
	}

	return FString(str.c_str());
}

FString NontaoImportExportUtils::GetLightTypeString(const aiLightSourceType type) {
	std::string str;

	switch (type) {
	default:
	case aiLightSource_UNDEFINED: {
		str = "UNDEFINED";
		break;
	}

								  //! A directional light source has a well-defined direction
								  //! but is infinitely far away. That's quite a good
								  //! approximation for sun light.
	case aiLightSource_DIRECTIONAL: {
		str = "DIRECTIONAL";
		break;
	}

									//! A point light source has a well-defined position
									//! in space but no direction - it emits light in all
									//! directions. A normal bulb is a point light.
	case aiLightSource_POINT: {
		str = "POINT";
		break;
	}

							  //! A spot light source emits light in a specific
							  //! angle. It has a position and a direction it is pointing to.
							  //! A good example for a spot light is a light spot in
							  //! sport arenas.
	case aiLightSource_SPOT: {
		str = "SPOT";
		break;
	}

							 //! The generic light level of the world, including the bounces
							 //! of all other light sources.
							 //! Typically, there's at most one ambient light in a scene.
							 //! This light type doesn't have a valid position, direction, or
							 //! other properties, just a color.
	case aiLightSource_AMBIENT: {
		str = "AMBIENT";
		break;
	}

								//! An area light is a rectangle with predefined size that uniformly
								//! emits light from one of its sides. The position is center of the
								//! rectangle and direction is its normal vector.
	case aiLightSource_AREA: {
		str = "AREA";
		break;
	}
	}

	return FString(UTF8_TO_TCHAR(str.c_str()));
}

const FString NontaoImportExportUtils::GetString(const aiString* value) {
	return FString(UTF8_TO_TCHAR(value->C_Str()));
}


const FString NontaoImportExportUtils::GetString(const aiString& value) {
	return GetString(&value);
}

FMatrix NontaoImportExportUtils::GetMatrix(const aiMatrix4x4* matrix4x4)
{
	FMatrix tempMatrix;
	GetMatrix(*matrix4x4, tempMatrix);
	return tempMatrix;
}

FMatrix NontaoImportExportUtils::GetMatrix(const aiMatrix4x4& matrix4x4)
{
	FMatrix tempMatrix;
	GetMatrix(matrix4x4, tempMatrix);
	return tempMatrix;
}

void NontaoImportExportUtils::GetMatrix(const aiMatrix4x4& matrix4x4, FMatrix& OutValue)
{
	const aiMatrix4x4& tempTrans = matrix4x4;
	OutValue.M[0][0] = tempTrans.a1; OutValue.M[0][1] = tempTrans.b1; OutValue.M[0][2] = tempTrans.c1; OutValue.M[0][3] = tempTrans.d1;
	OutValue.M[1][0] = tempTrans.a2; OutValue.M[1][1] = tempTrans.b2; OutValue.M[1][2] = tempTrans.c2; OutValue.M[1][3] = tempTrans.d2;
	OutValue.M[2][0] = tempTrans.a3; OutValue.M[2][1] = tempTrans.b3; OutValue.M[2][2] = tempTrans.c3; OutValue.M[2][3] = tempTrans.d3;
	OutValue.M[3][0] = tempTrans.a4; OutValue.M[3][1] = tempTrans.b4; OutValue.M[3][2] = tempTrans.c4; OutValue.M[3][3] = tempTrans.d4;
}

void NontaoImportExportUtils::GetMatrix(const FMatrix& matrix4x4, aiMatrix4x4& OutValue)
{
	const FMatrix& tempTrans = matrix4x4;
	OutValue.a1 = tempTrans.M[0][0]; OutValue.b1 = tempTrans.M[0][1]; OutValue.c1 = tempTrans.M[0][2]; OutValue.d1 = tempTrans.M[0][3];
	OutValue.a2 = tempTrans.M[1][0]; OutValue.b2 = tempTrans.M[1][1]; OutValue.c2 = tempTrans.M[1][2]; OutValue.d2 = tempTrans.M[1][3];
	OutValue.a3 = tempTrans.M[2][0]; OutValue.b3 = tempTrans.M[2][1]; OutValue.c3 = tempTrans.M[2][2]; OutValue.d3 = tempTrans.M[2][3];
	OutValue.a4 = tempTrans.M[3][0]; OutValue.b4 = tempTrans.M[3][1]; OutValue.c4 = tempTrans.M[3][2]; OutValue.d4 = tempTrans.M[3][3];

	//OutValue.M[0][0] = tempTrans.a1; OutValue.M[0][1] = tempTrans.b1; OutValue.M[0][2] = tempTrans.c1; OutValue.M[0][3] = tempTrans.d1;
	//OutValue.M[1][0] = tempTrans.a2; OutValue.M[1][1] = tempTrans.b2; OutValue.M[1][2] = tempTrans.c2; OutValue.M[1][3] = tempTrans.d2;
	//OutValue.M[2][0] = tempTrans.a3; OutValue.M[2][1] = tempTrans.b3; OutValue.M[2][2] = tempTrans.c3; OutValue.M[2][3] = tempTrans.d3;
	//OutValue.M[3][0] = tempTrans.a4; OutValue.M[3][1] = tempTrans.b4; OutValue.M[3][2] = tempTrans.c4; OutValue.M[3][3] = tempTrans.d4;
}

FVector NontaoImportExportUtils::GetVector(const aiVector3D* vec)
{
	return FVector(vec->x, vec->y, vec->z);
}

FVector NontaoImportExportUtils::GetVector(const aiVector3D& vec)
{
	return GetVector(&vec);
}

void NontaoImportExportUtils::GetVector(const aiVector3D& vec, FVector& OutValue)
{
	OutValue.X = vec.x;
	OutValue.Y = vec.y;
	OutValue.Z = vec.z;
}

FVector2D NontaoImportExportUtils::GetVector2D(const aiVector3D& vec)
{
	return FVector2D(vec.x, vec.y);
}

FVector2D NontaoImportExportUtils::GetVector2D(const aiVector3D* vec)
{
	return FVector2D(vec->x, vec->y);
}

void NontaoImportExportUtils::GetVector2D(const aiVector3D& vec, FVector2D& OutValue)
{
	OutValue.X = vec.x;
	OutValue.Y = vec.y;
}

FLinearColor NontaoImportExportUtils::GetLinearColor(const aiColor4D* color)
{
	return FLinearColor(color->r, color->g, color->b, color->a);
}

FLinearColor NontaoImportExportUtils::GetLinearColor(const aiColor4D& color)
{
	return FLinearColor(color.r, color.g, color.b, color.a);
}

void NontaoImportExportUtils::GetLinearColor(const aiColor4D& color, FLinearColor& OutValue)
{
	OutValue.R = color.r;
	OutValue.G = color.g;
	OutValue.B = color.b;
	OutValue.A = color.a;
}

FLinearColor NontaoImportExportUtils::GetLinearColor(const aiColor3D* color)
{
	return FLinearColor(color->r, color->g, color->b);
}

FLinearColor NontaoImportExportUtils::GetLinearColor(const aiColor3D& color)
{
	return FLinearColor(color.r, color.g, color.b);
}

void NontaoImportExportUtils::GetLinearColor(const aiColor3D& color, FLinearColor& OutValue)
{
	OutValue.R = color.r;
	OutValue.G = color.g;
	OutValue.B = color.b;
	OutValue.A = 1.0;
}

//void NontaoImportExportUtils::GetLinearColor(const aiColor4D& color, FLinearColor& OutValue)
//{
//	OutValue.R = color.r;
//	OutValue.G = color.g;
//	OutValue.B = color.b;
//	OutValue.A = color.a;
//}

void NontaoImportExportUtils::GetColor(const FLinearColor& color, aiColor3D& OutValue)
{
	OutValue.r = color.R;
	OutValue.g = color.G;
	OutValue.b = color.B;
	//OutValue.a = color.A;
}

void NontaoImportExportUtils::GetColor(const FLinearColor& color, aiColor4D& OutValue)
{
	OutValue.r = color.R;
	OutValue.g = color.G;
	OutValue.b = color.B;
	OutValue.a = color.A;
}

FColor NontaoImportExportUtils::GetColor(const aiColor4D* color)
{
	return FColor(color->r, color->g, color->b, color->a);
}

FColor NontaoImportExportUtils::GetColor(const aiColor4D& color)
{
	return FColor(color.r, color.g, color.b, color.a);
}

void NontaoImportExportUtils::GetColor(const aiColor4D& color, FColor& OutValue)
{
	OutValue.R = color.r;
	OutValue.G = color.g;
	OutValue.B = color.b;
	OutValue.A = color.a;
}


void NontaoImportExportUtils::GetQuaternion(const aiQuaternion& quat, FQuat& OutValue) {
	OutValue.X = quat.x;
	OutValue.Y = quat.y;
	OutValue.Z = quat.z;
	OutValue.W = quat.w;
}

void NontaoImportExportUtils::GetQuaternion(const FQuat& quat, aiQuaternion& OutValue){
	OutValue.x = quat.X;
	OutValue.y = quat.Y;
	OutValue.z = quat.Z;
	OutValue.w = quat.W;
}

//void NontaoImportExportUtils::GetColor(const FLinearColor& color, aiColor4D& OutValue) {
//	OutValue.r = color.R;
//	OutValue.g = color.G;
//	OutValue.b = color.B;
//	OutValue.a = color.A;
//}

void NontaoImportExportUtils::GetVector(const FVector2D& vec, aiVector3D& OutValue)
{
	OutValue.x = vec.X;
	OutValue.y = vec.Y;
	//OutValue.z = vec.Z;
}

void NontaoImportExportUtils::GetVector(const FVector& vec, aiVector3D& OutValue)
{
	OutValue.x = vec.X;
	OutValue.y = vec.Y;
	OutValue.z = vec.Z;
}

void NontaoImportExportUtils::GetArray(TArray<int>* Dst, const void* Src, const unsigned int Size) {
	FMemory::Memcpy(Dst->GetData(), Src, Size);
}

void NontaoImportExportUtils::GetArray(TArray<int>& Dst, const void* Src, const unsigned int Size) {
	GetArray(&Dst, Src, Size);
}


const aiString NontaoImportExportUtils::GetString(const FString& Value) 
{
	return aiString(std::string(TCHAR_TO_UTF8(*Value)));
}

template<typename S>
const aiString NontaoImportExportUtils::GetString(const TArray<S>& Value) {
	auto size = Value.Num() * sizeof(S);
	void* data = FMemory::Malloc(size);
	FMemory::Memcpy(data, Value.GetData(), size);
	return aiString(std::string((char*)data));
}

template<typename S>
const int NontaoImportExportUtils::GetData(void* Dst, const TArray<S>& Value) {
	auto size = sizeof(S) * Value.Num();
	//Dst = FMemory::Malloc(size);
	FMemory::Memcpy(Dst, Value.GetData(), size);
	return size;
}

template<typename D, typename S>
const int NontaoImportExportUtils::GetData(void* Dst, const TArray<S>& Value)
{
	auto size = sizeof(D);
	FMemory::Memcpy(Dst, Value.GetData(), size);
	return size;
}

const int NontaoImportExportUtils::GetMetadata(const TArray<FNontaoMeta>& Metas, aiMetadata*& Out)
{
	auto num = Metas.Num();
	auto aiMet = aiMetadata::Alloc(num);
	Out = aiMet;

	for (size_t m = 0; m < num; m++)
	{
		auto& meta = Metas[m];
		auto key = std::string(TCHAR_TO_UTF8(*meta.Name));//NontaoImportExportUtils::GetString(meta.Name);
		switch (meta.Type) {
		case ENontaoDataType::Nontao_BOOL: {
			bool value = *meta.Data.GetData();
			aiMet->Set(m, key, value);
			break;
		}
		case ENontaoDataType::Nontao_DOUBLE: {
			double value = *meta.Data.GetData();
			aiMet->Set(m, key, value);
			break;
		}
		case ENontaoDataType::Nontao_FLOAT: {
			float value = *meta.Data.GetData();
			aiMet->Set(m, key, value);
			break;
		}
		case ENontaoDataType::Nontao_INT32: {
			//...
			long value = *meta.Data.GetData();
			aiMet->Set(m, key, value);
			break;
		}
		case ENontaoDataType::Nontao_STRING: {
			//aiString value;
			//NontaoImportExportUtils::GetData<aiString>(&value, meta.Data);
			aiString value = NontaoImportExportUtils::GetString<int>(meta.Data);
			aiMet->Set(m, key, value);
			break;
		}
		case ENontaoDataType::Nontao_UINT64: {
			uint64_t value = *meta.Data.GetData();
			aiMet->Set(m, key, value);
			break;
		}
		case ENontaoDataType::Nontao_VECTOR: {
			aiVector3D value;
			NontaoImportExportUtils::GetData<bool>(&value, meta.Data);
			aiMet->Set(m, key, value);
			break;
		}
		}
	}

	return Metas.Num();
}


