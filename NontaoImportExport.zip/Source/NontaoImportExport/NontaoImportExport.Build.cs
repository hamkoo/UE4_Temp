// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.

using UnrealBuildTool;
using System.IO;
using System;

public class NontaoImportExport : ModuleRules
{
    private string ModulePath
    {
        get { return ModuleDirectory; }
    }

    private string ThirdPartyPath
    {
        get { return Path.GetFullPath(Path.Combine(ModulePath, "../ThirdParty/")); }
    }


    public NontaoImportExport(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;

        
		
		PublicIncludePaths.AddRange(
			new string[] {
				// ... add public include paths required here ...
                "./",
                Path.Combine(ThirdPartyPath, "assimp/include"),
            }
			);
				
		
		PrivateIncludePaths.AddRange(
			new string[] {
				// ... add other private include paths required here ...
                "./",
                ThirdPartyPath,
                Path.Combine(ThirdPartyPath, "assimp/include"),
            }
			);
			
		
		PublicDependencyModuleNames.AddRange(
			new string[]
			{
				"Core",
				// ... add other public dependencies that you statically link with here ...
				"ProceduralMeshComponent",
			}
			);
			
		
		PrivateDependencyModuleNames.AddRange(
			new string[]
			{
				"CoreUObject",
				"Engine",
				"Slate",
				"SlateCore",
				// ... add private dependencies that you statically link with here ...	
                "ProceduralMeshComponent",
                "DesktopPlatform"
            }
			);
		
		
		DynamicallyLoadedModuleNames.AddRange(
			new string[]
			{
				// ... add any modules that your module loads dynamically here ...
			}
			);

        if ((Target.Platform == UnrealTargetPlatform.Win64) || (Target.Platform == UnrealTargetPlatform.Win32))
        {
            string PlatformString = (Target.Platform == UnrealTargetPlatform.Win64) ? "Win64" : "Win32";
            PublicAdditionalLibraries.Add(Path.Combine(ThirdPartyPath, "assimp/lib", PlatformString, "assimp-vc141-mt.lib"));
            //RuntimeDependencies.Add(new RuntimeDependency(Path.Combine(ThirdPartyPath, "assimp/bin", PlatformString, "assimp-vc141-mt.dll")));
            RuntimeDependencies.Add(Path.Combine(ThirdPartyPath, "assimp/bin", PlatformString, "assimp-vc141-mt.dll"));

            if (System.IO.Directory.Exists(Path.Combine(ModuleDirectory, "../../Binaries", PlatformString))== false) {
                System.IO.Directory.CreateDirectory(Path.Combine(ModuleDirectory, "../../Binaries", PlatformString));
            }

            System.IO.File.Copy(
                Path.Combine(ThirdPartyPath, "assimp/bin", PlatformString, "assimp-vc141-mt.dll"),
                Path.Combine(ModuleDirectory, "../../Binaries", PlatformString, "assimp-vc141-mt.dll"),
                true);


        }
        else if (Target.Platform == UnrealTargetPlatform.Mac)
        {
            string PlatformString = "Mac";
            PublicAdditionalLibraries.Add(Path.Combine(ThirdPartyPath, "assimp/lib", PlatformString, "libassimp.4.1.0.dylib"));
        }
        //if (Target.Platform == UnrealTargetPlatform.Android)
        //{
        //    string PlatformString = "android";
        //    PublicAdditionalLibraries.Add(Path.Combine(ThirdPartyPath, "assimp/lib", PlatformString, "libassimp.so"));

        //    //RuntimeDependencies.Add(new RuntimeDependency(Path.Combine(ThirdPartyPath, "assimp/bin", PlatformString, "assimp-vc140-mt.dll")));
        //}
    }
}
